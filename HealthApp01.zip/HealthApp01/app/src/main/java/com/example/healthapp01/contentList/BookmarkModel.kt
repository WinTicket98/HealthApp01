package com.example.healthapp01.contentList

// 북마크 모델
data class BookmarkModel(
    val bookmarkIsTrue : Boolean? = true  // Image 클릭을 Boolean 으로 처리
)